from flask import Flask, render_template, request, jsonify
import urllib.request
import urllib.parse
import json
import re
import math
from collections import Counter, defaultdict
from spellchecker import SpellChecker

app = Flask(__name__)
spell = SpellChecker(distance=1)

AUXILIARY_VERBS = {
    'be': {'am', 'are', 'is', 'was', 'were', 'been', 'being'},
    'have': {'have', 'has', 'had'},
    'do': {'do', 'does', 'did'},
    'modal': {'can', 'could', 'will', 'would', 'should', 'may', 'might', 'must'}
}

SINGULAR_SUBJECTS = {'he', 'she', 'it', 'this', 'that', 'someone', 'anyone', 'everyone'}
PLURAL_SUBJECTS = {'they', 'we', 'you', 'these', 'those', 'many', 'several'}
FORMAL_HINTS = {'please', 'kindly', 'kind regards', 'sincerely', 'would you', 'could you', 'appreciate'}
INFORMAL_HINTS = {'lol', 'hey', 'wanna', 'gonna', 'ya', 'dude', 'bro', 'awesome', 'cool', 'okay', 'ok'}
GRAMMAR_TOOL_URL = 'https://api.languagetool.org/v2/check'

TONE_TRAINING_DATA = {
    'Formal': [
        'Please review the attached document before the meeting.',
        'We appreciate your prompt attention to this matter.',
        'Could you kindly provide the requested information?',
        'Sincerely, I look forward to your response.',
        'The proposal should be submitted by Friday.'
    ],
    'Informal': [
        'Hey, can you check this out?',
        'I am gonna send it over later, cool?',
        'That sounds awesome, let me know.',
        'LOL this is so funny, I cant wait!',
        'You should totally go for it, dude.'
    ],
    'Neutral': [
        'The report is due tomorrow.',
        'The system is ready for testing.',
        'There are updates available for the software.',
        'The meeting starts at 3 PM.',
        'Please confirm the schedule.'
    ]
}

POS_LEXICON = {
    'i': 'PRP', 'me': 'PRP', 'you': 'PRP', 'he': 'PRP', 'she': 'PRP', 'it': 'PRP', 'we': 'PRP', 'they': 'PRP', 'them': 'PRP',
    'this': 'DT', 'that': 'DT', 'these': 'DT', 'those': 'DT', 'a': 'DT', 'an': 'DT', 'the': 'DT',
    'and': 'CC', 'or': 'CC', 'but': 'CC', 'nor': 'CC', 'so': 'CC', 'yet': 'CC', 'for': 'CC',
    'because': 'IN', 'although': 'IN', 'though': 'IN', 'if': 'IN', 'unless': 'IN', 'since': 'IN', 'while': 'IN',
    'is': 'VBZ', 'are': 'VBP', 'am': 'VBP', 'was': 'VBD', 'were': 'VBD', 'has': 'VBZ', 'have': 'VBP', 'had': 'VBD',
    'do': 'VBP', 'does': 'VBZ', 'did': 'VBD', 'will': 'MD', 'would': 'MD', 'should': 'MD', 'could': 'MD', 'may': 'MD',
    'must': 'MD', 'can': 'MD', 'shall': 'MD', 'might': 'MD', 'ought': 'MD',
    'very': 'RB', 'really': 'RB', 'quickly': 'RB', 'slowly': 'RB', 'well': 'RB', 'badly': 'RB', 'hard': 'RB',
    'today': 'NN', 'yesterday': 'NN', 'tomorrow': 'NN', 'now': 'RB', 'then': 'RB', 'here': 'RB', 'there': 'RB',
    'in': 'IN', 'on': 'IN', 'at': 'IN', 'to': 'TO', 'for': 'IN', 'with': 'IN', 'by': 'IN', 'from': 'IN', 'of': 'IN',
    'about': 'IN', 'after': 'IN', 'before': 'IN', 'during': 'IN', 'under': 'IN', 'over': 'IN', 'between': 'IN',
    'good': 'JJ', 'bad': 'JJ', 'big': 'JJ', 'small': 'JJ', 'happy': 'JJ', 'sad': 'JJ', 'fast': 'JJ', 'slow': 'JJ',
    'red': 'JJ', 'blue': 'JJ', 'green': 'JJ', 'yellow': 'JJ', 'black': 'JJ', 'white': 'JJ',
    'run': 'VB', 'eat': 'VB', 'sleep': 'VB', 'walk': 'VB', 'talk': 'VB', 'write': 'VB', 'read': 'VB', 'play': 'VB',
    'went': 'VBD', 'gone': 'VBN', 'done': 'VBN', 'saw': 'VBD', 'seen': 'VBN', 'came': 'VBD', 'come': 'VB'
}
COMMON_VERBS = {
    'go', 'come', 'make', 'take', 'see', 'say', 'get', 'give', 'find', 'think', 'tell', 'ask',
    'work', 'need', 'feel', 'become', 'leave', 'put', 'keep', 'mean', 'let', 'begin', 'seem',
    'help', 'talk', 'turn', 'start', 'show', 'hear', 'play', 'run', 'move', 'live', 'believe',
    'hold', 'bring', 'happen', 'write', 'provide', 'sit', 'stand', 'lose', 'pay', 'meet',
    'include', 'continue', 'set', 'learn', 'change', 'lead', 'understand', 'watch', 'follow',
    'stop', 'create', 'speak', 'read', 'allow', 'add', 'spend', 'grow', 'open', 'walk', 'win',
    'offer', 'remember', 'love', 'consider', 'report', 'help', 'use', 'require', 'say',
    'eat', 'sleep', 'drink', 'buy', 'sell', 'drive', 'fly', 'swim', 'jump', 'sing', 'dance'
}

OBJECT_SUBJECT_MAP = {
    'me': 'I', 'him': 'he', 'her': 'she', 'us': 'we', 'them': 'they'
}
OBJECTIVE_PRONOUNS = set(OBJECT_SUBJECT_MAP.keys())
TIME_NOUNS = {'today', 'yesterday', 'tomorrow', 'now'}
DOUBLE_NEGATIVES = {'nothing', 'nobody', 'nowhere', 'none', 'never'}
WRONG_USAGE_PATTERNS = [
    (r'\btoo late for buying nothing\b', 'too late to buy anything'),
    (r'\bfor buying nothing\b', 'to buy anything'),
    (r'\bfor buying\b', 'to buy')
]
IRREGULAR_PAST = {
    'go': 'went', 'goes': 'went', 'be': 'was', 'am': 'was', 'are': 'were', 'is': 'was', 'have': 'had', 'do': 'did',
    'buy': 'bought', 'come': 'came', 'take': 'took', 'make': 'made', 'see': 'saw', 'say': 'said',
    'get': 'got', 'give': 'gave', 'find': 'found', 'think': 'thought', 'tell': 'told', 'eat': 'ate',
    'write': 'wrote', 'read': 'read', 'sell': 'sold', 'drive': 'drove', 'fly': 'flew', 'sleep': 'slept'
}
SUBJECT_PRONOUNS = {'i', 'you', 'he', 'she', 'it', 'we', 'they'}

PRESENT_TERMS = {'is', 'are', 'am', 'has', 'have', 'do', 'does', 'can', 'will', 'shall', 'may', 'must', 'should'}
PAST_TERMS = {'was', 'were', 'had', 'did', 'could', 'would', 'might', 'ought', 'went', 'bought'}
FUTURE_TERMS = {'will', 'shall', 'would', 'could', 'should', 'may', 'might', 'must'}


def tokenize_text(text):
    # Improved tokenization: handle contractions, punctuation attached
    tokens = re.findall(r"\b\w+(?:'\w+)?\b|[^\w\s]", text, re.UNICODE)
    return tokens


def pos_tag_text(tokens):
    tagged = []
    for i, token in enumerate(tokens):
        lower = token.lower()
        if lower in POS_LEXICON:
            tag = POS_LEXICON[lower]
            # Refine verb tags based on context
            if tag == 'VB':
                if lower.endswith('ed') and len(lower) > 2:
                    tag = 'VBD'  # past tense
                elif lower.endswith('ing') and len(lower) > 3:
                    tag = 'VBG'  # gerund
                elif lower.endswith('s') and lower[:-1] in COMMON_VERBS:
                    tag = 'VBZ'  # third person singular
                elif lower in {'is', 'am', 'are', 'was', 'were', 'be', 'been', 'being'}:
                    tag = 'VB'  # be verbs are VB by default, but can be refined
                    if lower in {'is', 'am', 'are'}:
                        tag = 'VBP' if lower in {'am', 'are'} else 'VBZ'
                    elif lower in {'was', 'were'}:
                        tag = 'VBD'
                elif lower in {'have', 'has', 'had'}:
                    tag = 'VBP' if lower == 'have' else 'VBZ' if lower == 'has' else 'VBD'
                elif lower in {'do', 'does', 'did'}:
                    tag = 'VBP' if lower == 'do' else 'VBZ' if lower == 'does' else 'VBD'
                elif lower in {'will', 'would', 'should', 'could', 'may', 'might', 'must', 'can', 'shall'}:
                    tag = 'MD'  # modal
            tagged.append((token, tag))
        elif re.fullmatch(r"\d+", lower):
            tagged.append((token, 'CD'))
        elif token in '.!?':
            tagged.append((token, '.'))
        elif lower.endswith('ly'):
            tagged.append((token, 'RB'))
        elif lower.endswith('ed') and len(lower) > 2:
            tagged.append((token, 'VBD'))
        elif lower.endswith('ing') and len(lower) > 3:
            tagged.append((token, 'VBG'))
        elif lower.endswith('en') and len(lower) > 2:
            tagged.append((token, 'VBN'))  # default to base verb
        elif lower in COMMON_VERBS:
            tagged.append((token, 'VB'))
        elif i > 0 and tagged[i-1][1] in {'PRP', 'NN', 'NNS', 'DT'} and lower not in {'a', 'an', 'the', 'and', 'or', 'but', 'because', 'although', 'if', 'the', 'a', 'an'}:
            tagged.append((token, 'VB'))
        elif lower.endswith('s') and lower[:-1] in COMMON_VERBS:
            tagged.append((token, 'VBZ'))
        else:
            # Default to NN, but check for JJ
            if lower in {'good', 'bad', 'big', 'small', 'happy', 'sad', 'fast', 'slow', 'red', 'blue', 'green', 'yellow', 'black', 'white'} or lower.endswith('able') or lower.endswith('ful') or lower.endswith('ous'):
                tagged.append((token, 'JJ'))
            else:
                tagged.append((token, 'NN'))
    return tagged


def dependency_parse(tokens, tags):
    dependencies = []
    subject = None
    verb = None
    obj = None
    for i, (token, tag) in enumerate(tags):
        if tag in {'PRP', 'NN', 'NNS'}:
            if subject is None:
                subject = (token, i)
            elif obj is None and verb is not None:
                obj = (token, i)
                dependencies.append({'head': verb[0], 'relation': 'obj', 'dependent': token})
        elif tag.startswith('VB') or tag == 'MD':
            if verb is None:
                verb = (token, i)
                if subject:
                    dependencies.append({'head': token, 'relation': 'nsubj', 'dependent': subject[0]})
        elif tag == 'IN' or tag == 'TO':
            # Preposition or to
            if i + 1 < len(tags) and tags[i+1][1] in {'NN', 'PRP'}:
                dependencies.append({'head': tags[i+1][0], 'relation': 'prep', 'dependent': token})
    return dependencies


def count_syllables(word):
    word = word.lower()
    word = re.sub(r'[^a-z]', '', word)
    if not word:
        return 0
    groups = re.findall(r'[aeiouy]+', word)
    count = len(groups)
    if word.endswith('e') and len(groups) > 1:
        count -= 1
    if word.endswith('le') and len(word) > 2 and word[-3] not in 'aeiouy':
        count += 1
    return max(count, 1)


def flesch_reading_ease(text):
    sentences = [s for s in re.split(r'(?<=[.!?])\s+', text.strip()) if s.strip()]
    words = re.findall(r"\b[a-zA-Z']+\b", text)
    if len(words) == 0 or len(sentences) == 0:
        return 0.0
    syllables = sum(count_syllables(word) for word in words)
    score = 206.835 - 1.015 * (len(words) / len(sentences)) - 84.6 * (syllables / len(words))
    return round(score, 1)


def analyze_tone(text):
    lower = text.lower()
    formal_matches = sum(1 for phrase in FORMAL_HINTS if phrase in lower)
    informal_matches = sum(1 for phrase in INFORMAL_HINTS if phrase in lower)
    if formal_matches > informal_matches:
        tone = 'Formal'
        explanation = 'The text uses polite and professional language signals.'
    elif informal_matches > formal_matches:
        tone = 'Informal'
        explanation = 'The text uses conversational, casual language signals.'
    else:
        tone = 'Neutral'
        explanation = 'The style is balanced and relatively neutral.'
    return {'tone': tone, 'explanation': explanation}


def compute_word_count(text):
    return len(re.findall(r"\b[a-zA-Z']+\b", text))


def check_grammar_online(text):
    data = urllib.parse.urlencode({
        'text': text,
        'language': 'en-US',
        'enabledOnly': 'false'
    }).encode('utf-8')
    try:
        req = urllib.request.Request(GRAMMAR_TOOL_URL, data=data, method='POST')
        with urllib.request.urlopen(req, timeout=10) as response:
            charset = response.headers.get_content_charset() or 'utf-8'
            payload = response.read().decode(charset, errors='replace')
            result = json.loads(payload)
            errors = []
            for match in result.get('matches', []):
                errors.append({
                    'message': match['message'],
                    'suggestions': [s['value'] for s in match.get('replacements', [])[:3]],
                    'explanation': match.get('message'),
                    'context': match.get('context', {}).get('text', ''),
                    'target': match.get('context', {}).get('text', ''),
                    'correction': match.get('replacements', [])[0]['value'] if match.get('replacements') else ''
                })
            return errors
    except Exception:
        return []


def to_third_person_singular(verb):
    if verb.endswith('y') and len(verb) > 1 and verb[-2] not in 'aeiou':
        return verb[:-1] + 'ies'
    if verb.endswith(('o', 'ch', 'sh', 'ss', 'x', 'z')):
        return verb + 'es'
    if verb == 'have':
        return 'has'
    if verb == 'do':
        return 'does'
    if verb == 'go':
        return 'goes'
    return verb + 's'


def to_past_simple(verb):
    if verb in IRREGULAR_PAST:
        return IRREGULAR_PAST[verb]
    if verb.endswith('ies') and len(verb) > 3:
        return verb[:-3] + 'ied'
    if verb.endswith('es') and len(verb) > 2:
        return verb[:-2]
    if verb.endswith('e'):
        return verb + 'd'
    if verb.endswith('y') and len(verb) > 1 and verb[-2] not in 'aeiou':
        return verb[:-1] + 'ied'
    return verb + 'ed'


def token_to_base_form(token):
    lower = token.lower()
    for base, past in IRREGULAR_PAST.items():
        if lower == past:
            return base
    if lower.endswith('ies') and len(lower) > 3:
        return lower[:-3] + 'y'
    if lower.endswith('ed') and len(lower) > 2:
        return lower[:-2]
    if lower.endswith('s') and lower[:-1] in COMMON_VERBS:
        return lower[:-1]
    return lower


def detect_pronoun_issues(tokens, tags, sentence):
    issues = []
    lower_tokens = [t.lower() for t in tokens]
    if len(lower_tokens) >= 3 and lower_tokens[1] == 'and' and lower_tokens[0] in OBJECTIVE_PRONOUNS and lower_tokens[2] in OBJECTIVE_PRONOUNS:
        corrected_order = []
        for token in [lower_tokens[0], lower_tokens[2]]:
            corrected_order.append(OBJECT_SUBJECT_MAP.get(token, token))
        corrected = f"{corrected_order[1].capitalize()} and {corrected_order[0]}"
        if lower_tokens[0] == 'me' and lower_tokens[2] in {'him', 'her'}:
            corrected = f"{OBJECT_SUBJECT_MAP[lower_tokens[2]].capitalize()} and I"
        issues.append({
            'message': 'Incorrect subject pronouns: use subject pronouns in the subject position.',
            'suggestions': [corrected],
            'explanation': 'Object pronouns like "me" and "him" should not be used as the subject of a clause.',
            'context': sentence,
            'target': ' '.join(tokens[:3]),
            'correction': corrected
        })
    elif len(lower_tokens) >= 2 and lower_tokens[0] in OBJECTIVE_PRONOUNS and tags[1][1].startswith('VB'):
        corrected = OBJECT_SUBJECT_MAP.get(lower_tokens[0], lower_tokens[0]).capitalize()
        issues.append({
            'message': 'Incorrect subject pronoun used in the beginning of the sentence.',
            'suggestions': [corrected],
            'explanation': 'Use subject pronouns like "I" or "he" when the pronoun is the subject of a sentence.',
            'context': sentence,
            'target': tokens[0],
            'correction': corrected
        })
    return issues


def detect_double_negative_issues(tokens, sentence):
    issues = []
    lower_tokens = [t.lower() for t in tokens]
    for idx, token in enumerate(lower_tokens):
        if token in {'not', 'never', 'no'}:
            for later in lower_tokens[idx + 1:]:
                if later in DOUBLE_NEGATIVES:
                    target = ' '.join(tokens[idx:idx + 2]) if later == lower_tokens[idx + 1] else ' '.join(tokens[idx:idx + 3])
                    issues.append({
                        'message': 'Double negative detected.',
                        'suggestions': ['Rephrase to avoid double negatives.'],
                        'explanation': 'Using two negatives in a sentence often reverses the meaning or creates awkward grammar.',
                        'context': sentence,
                        'target': target,
                        'correction': 'anything'
                    })
                    return issues
    return issues


def detect_wrong_usage_issues(sentence):
    issues = []
    lower = sentence.lower()
    if 'too late for buying nothing' in lower:
        issues.append({
            'message': 'Incorrect phrase: "too late for buying nothing".',
            'suggestions': ['Use "too late to buy anything".'],
            'explanation': 'The phrase should use an infinitive and avoid a double negative.',
            'context': sentence,
            'target': 'too late for buying nothing',
            'correction': 'too late to buy anything'
        })
    elif 'for buying' in lower:
        issues.append({
            'message': 'Improper phrase usage: "for buying" may be wrong in this context.',
            'suggestions': ['Use "to buy" instead.'],
            'explanation': 'After phrases like "too late", the infinitive form "to buy" is more natural than "for buying".',
            'context': sentence,
            'target': 'for buying',
            'correction': 'to buy'
        })
    return issues


def detect_subject_verb_issues(tokens, tags, sentence):
    issues = []
    dependencies = dependency_parse(tokens, tags)
    subjects = [d for d in dependencies if d['relation'] == 'nsubj']
    for dep in subjects:
        subj = dep['dependent']
        verb = dep['head']
        subj_lower = subj.lower()
        verb_lower = verb.lower()
        if subj_lower in SINGULAR_SUBJECTS:
            if verb_lower in {'are', 'were', 'have', 'do'}:
                correction = {'are': 'is', 'were': 'was', 'have': 'has', 'do': 'does'}[verb_lower]
                issues.append({
                    'message': f'Subject-verb agreement error: "{subj} {verb}" should be "{subj} {correction}".',
                    'suggestions': [correction],
                    'explanation': 'A singular subject requires a singular verb form.',
                    'context': sentence,
                    'target': f'{subj} {verb}',
                    'correction': f'{subj} {correction}'
                })
            elif verb_lower.endswith('s') and verb_lower[:-1] in COMMON_VERBS:
                pass
            elif verb_lower in COMMON_VERBS and not verb_lower.endswith('s'):
                correction = verb_lower + 's'
                issues.append({
                    'message': f'Subject-verb agreement error: "{subj} {verb}" should be "{subj} {correction}".',
                    'suggestions': [correction],
                    'explanation': 'A singular subject requires the verb to end with -s in present tense.',
                    'context': sentence,
                    'target': f'{subj} {verb}',
                    'correction': f'{subj} {correction}'
                })
        elif subj_lower in PLURAL_SUBJECTS:
            if verb_lower in {'is', 'was', 'has', 'does'}:
                correction = {'is': 'are', 'was': 'were', 'has': 'have', 'does': 'do'}[verb_lower]
                issues.append({
                    'message': f'Subject-verb agreement error: "{subj} {verb}" should be "{subj} {correction}".',
                    'suggestions': [correction],
                    'explanation': 'A plural subject requires a plural verb form.',
                    'context': sentence,
                    'target': f'{subj} {verb}',
                    'correction': f'{subj} {correction}'
                })
    # Additional pattern-based detection for repeated subject-verb pairs
    for i, (token, tag) in enumerate(tags):
        if tag == 'PRP' and token.lower() in PLURAL_SUBJECTS:
            for j in range(i + 1, min(i + 4, len(tags))):
                next_token, next_tag = tags[j]
                if next_tag.startswith('VB'):
                    verb_lower = next_token.lower()
                    if verb_lower in {'is', 'was', 'has', 'does'}:
                        correction = {'is': 'are', 'was': 'were', 'has': 'have', 'does': 'do'}[verb_lower]
                        issues.append({
                            'message': f'Subject-verb agreement error: "{token} {next_token}" should be "{token} {correction}".',
                            'suggestions': [correction],
                            'explanation': 'A plural subject requires a plural verb form.',
                            'context': sentence,
                            'target': f'{token} {next_token}',
                            'correction': f'{token} {correction}'
                        })
                    break
    return issues


def detect_tense_issues(tokens, tags, sentence):
    issues = []
    lower_tokens = [t.lower() for t in tokens]
    present_verbs = [token for token, tag in tags if tag in {'VBP', 'VBZ', 'VB'} and token.lower() not in {'will', 'shall', 'should', 'could', 'may', 'might', 'must'}]
    past_verbs = [token for token, tag in tags if tag == 'VBD']
    has_yesterday = 'yesterday' in lower_tokens
    has_tomorrow = 'tomorrow' in lower_tokens
    has_today = 'today' in lower_tokens

    if has_yesterday and present_verbs:
        verb = present_verbs[0]
        correction = IRREGULAR_PAST.get(verb.lower(), to_past_simple(verb.lower()))
        issues.append({
            'message': f'Tense inconsistency: "yesterday" with present tense verb "{verb}".',
            'suggestions': [f'Use past tense: "{correction}".'],
            'explanation': 'Time expressions like "yesterday" usually require past tense verbs.',
            'context': sentence,
            'target': verb,
            'correction': correction
        })
    if has_tomorrow and past_verbs and not present_verbs:
        verb = past_verbs[0]
        correction = f'will {token_to_base_form(verb)}'
        issues.append({
            'message': f'Tense inconsistency: "tomorrow" with past tense verb "{verb}".',
            'suggestions': ['Use future or present tense instead.'],
            'explanation': 'Future time expressions require future or present tense.',
            'context': sentence,
            'target': verb,
            'correction': correction
        })
    if has_today and past_verbs and not present_verbs:
        verb = past_verbs[0]
        correction = token_to_base_form(verb)
        issues.append({
            'message': f'Tense inconsistency: "today" with past tense verb "{verb}".',
            'suggestions': [f'Use present tense: "{correction}".'],
            'explanation': 'Current time expressions like "today" typically use present tense.',
            'context': sentence,
            'target': verb,
            'correction': correction
        })
    if present_verbs and past_verbs:
        has_been = 'been' in lower_tokens or ('have' in lower_tokens and 'been' in lower_tokens)
        if not has_been:
            issues.append({
                'message': 'Mixed tenses detected in the sentence.',
                'suggestions': ['Choose one tense for consistency.'],
                'explanation': 'Sentences should maintain consistent tense unless indicating a deliberate time shift.',
                'context': sentence
            })
    return issues


def detect_punctuation_issues(sentence):
    issues = []
    stripped = sentence.strip()
    if stripped and not stripped.endswith(('.','!','?')):
        issues.append({
            'message': 'Missing end punctuation.',
            'suggestions': ['Add a period (.), question mark (?), or exclamation mark (!) at the end.'],
            'explanation': 'Sentences typically end with punctuation to indicate completion.',
            'context': sentence
        })
    # Check for comma splices: two independent clauses joined by comma without conjunction
    clauses = re.split(r'[,.!?]', stripped)
    if len(clauses) > 1:
        for i in range(len(clauses)-1):
            if ',' in clauses[i] and not any(word in clauses[i].lower() for word in ['and', 'but', 'or', 'so', 'yet']):
                issues.append({
                    'message': 'Possible comma splice: two sentences joined incorrectly.',
                    'suggestions': ['Add a conjunction or split into separate sentences.'],
                    'explanation': 'Comma splices occur when independent clauses are joined only by a comma.',
                    'context': sentence
                })
                break
    return issues


def detect_structure_issues(tags, sentence):
    issues = []
    has_verb = any(tag.startswith('VB') or tag == 'MD' for _, tag in tags)
    has_subject = any(tag in {'PRP', 'NN', 'NNS'} for _, tag in tags)
    lower = sentence.lower()
    if not has_verb:
        issues.append({
            'message': 'Sentence fragment: missing a verb.',
            'suggestions': ['Add a verb to form a complete sentence.'],
            'explanation': 'Complete sentences require at least a subject and a verb.',
            'context': sentence
        })
    if not has_subject:
        issues.append({
            'message': 'Sentence fragment: missing a clear subject.',
            'suggestions': ['Add a subject (noun or pronoun).'],
            'explanation': 'Sentences need a subject to indicate who or what is performing the action.',
            'context': sentence
        })
    if lower.startswith(('because', 'although', 'if', 'when', 'since')) and not re.search(r'\b(and|but|or|so)\b', lower):
        issues.append({
            'message': 'Dependent clause without main clause.',
            'suggestions': ['Add an independent clause.'],
            'explanation': 'Subordinating conjunctions introduce dependent clauses that need a main clause.',
            'context': sentence
        })
    if re.search(r'\btoo late for buying nothing\b', lower):
        issues.append({
            'message': 'Incorrect structure: "too late for buying nothing".',
            'suggestions': ['Use "too late to buy anything" instead.'],
            'explanation': 'The phrase should use an infinitive and avoid a double negative for correct English.',
            'context': sentence,
            'target': 'too late for buying nothing',
            'correction': 'too late to buy anything'
        })
    # Check for run-on sentences: multiple subjects/verbs without punctuation
    verb_count = sum(1 for _, tag in tags if tag.startswith('VB'))
    subject_count = sum(1 for _, tag in tags if tag in {'PRP', 'NN', 'NNS'})
    if verb_count > 1 and subject_count > 1 and not any(t in '.!?' for t, _ in tags):
        issues.append({
            'message': 'Possible run-on sentence.',
            'suggestions': ['Add punctuation or conjunctions to separate clauses.'],
            'explanation': 'Run-on sentences combine multiple independent clauses without proper separation.',
            'context': sentence
        })
    return issues


def detect_article_issues(tokens, tags, sentence):
    issues = []
    verb_tags = {'VB', 'VBZ', 'VBP', 'VBD', 'VBG', 'VBN', 'MD'}
    for i, (token, tag) in enumerate(tags):
        lower = token.lower()
        if tag == 'NN' and lower not in {'a', 'an', 'the'} and lower not in TIME_NOUNS and lower not in OBJECTIVE_PRONOUNS and lower not in SUBJECT_PRONOUNS:
            if i > 0:
                prev_token, prev_tag = tags[i-1]
                if prev_tag == 'DT':
                    if lower.startswith(('a', 'e', 'i', 'o', 'u')) and prev_token.lower() == 'a':
                        issues.append({
                            'message': f'Incorrect article: "{prev_token}" should be "an" before "{token}".',
                            'suggestions': ['an'],
                            'explanation': 'Use "an" before words starting with a vowel sound.',
                            'context': sentence,
                            'target': prev_token,
                            'correction': 'an'
                        })
                    elif not lower.startswith(('a', 'e', 'i', 'o', 'u')) and prev_token.lower() == 'an':
                        issues.append({
                            'message': f'Incorrect article: "{prev_token}" should be "a" before "{token}".',
                            'suggestions': ['a'],
                            'explanation': 'Use "a" before words starting with a consonant sound.',
                            'context': sentence,
                            'target': prev_token,
                            'correction': 'a'
                        })
                elif prev_tag not in verb_tags and lower not in TIME_NOUNS:
                    if lower.startswith(('a', 'e', 'i', 'o', 'u')):
                        issues.append({
                            'message': f'Missing article: Add "an" before "{token}".',
                            'suggestions': ['an'],
                            'explanation': 'Nouns often need articles like "an" before vowel-starting words.',
                            'context': sentence,
                            'target': token,
                            'correction': f'an {token}'
                        })
                    else:
                        issues.append({
                            'message': f'Missing article: Add "a" before "{token}".',
                            'suggestions': ['a'],
                            'explanation': 'Nouns often need articles like "a" before consonant-starting words.',
                            'context': sentence,
                            'target': token,
                            'correction': f'a {token}'
                        })
            else:
                if lower.startswith(('a', 'e', 'i', 'o', 'u')):
                    issues.append({
                        'message': f'Missing article: Add "an" before "{token}".',
                        'suggestions': ['an'],
                        'explanation': 'Nouns often need articles like "an" before vowel-starting words.',
                        'context': sentence,
                        'target': token,
                        'correction': f'an {token}'
                    })
                else:
                    issues.append({
                        'message': f'Missing article: Add "a" before "{token}".',
                        'suggestions': ['a'],
                        'explanation': 'Nouns often need articles like "a" before consonant-starting words.',
                        'context': sentence,
                        'target': token,
                        'correction': f'a {token}'
                    })
    return issues


def analyze_grammar(text):
    sentences = [sentence.strip() for sentence in re.split(r'(?<=[.!?])\s+', text.strip()) if sentence.strip()]
    errors = []
    for sentence in sentences:
        tokens = tokenize_text(sentence)
        tags = pos_tag_text(tokens)
        errors.extend(detect_subject_verb_issues(tokens, tags, sentence))
        errors.extend(detect_pronoun_issues(tokens, tags, sentence))
        errors.extend(detect_tense_issues(tokens, tags, sentence))
        errors.extend(detect_double_negative_issues(tokens, sentence))
        errors.extend(detect_wrong_usage_issues(sentence))
        errors.extend(detect_punctuation_issues(sentence))
        errors.extend(detect_structure_issues(tags, sentence))
        errors.extend(detect_article_issues(tokens, tags, sentence))
    return errors


def merge_grammar_results(tool_errors, rule_errors):
    seen = set()
    merged = []
    for error in tool_errors + rule_errors:
        key = (error.get('message'), error.get('context'))
        if key not in seen:
            seen.add(key)
            merged.append(error)
    return merged


def tokenize_for_tone(text):
    return [word.lower() for word in re.findall(r"\b[a-zA-Z']+\b", text)]


def train_tone_classifier():
    class_counts = {label: len(samples) for label, samples in TONE_TRAINING_DATA.items()}
    total_samples = sum(class_counts.values())
    vocabulary = set()
    word_counts = {label: Counter() for label in TONE_TRAINING_DATA}

    for label, samples in TONE_TRAINING_DATA.items():
        for sentence in samples:
            for token in tokenize_for_tone(sentence):
                vocabulary.add(token)
                word_counts[label][token] += 1

    totals = {label: sum(counter.values()) for label, counter in word_counts.items()}
    vocab_size = len(vocabulary)

    priors = {label: math.log(count / total_samples) for label, count in class_counts.items()}
    likelihoods = {}
    for label, counter in word_counts.items():
        likelihoods[label] = defaultdict(float)
        for token, count in counter.items():
            likelihoods[label][token] = math.log((count + 1) / (totals[label] + vocab_size))
        likelihoods[label]['<UNK>'] = math.log(1 / (totals[label] + vocab_size))

    return {
        'priors': priors,
        'likelihoods': likelihoods,
        'totals': totals,
        'vocab_size': vocab_size
    }


TONE_MODEL = train_tone_classifier()


def predict_tone(text):
    tokens = tokenize_for_tone(text)
    if not tokens:
        return 'Neutral', {
            'tone': 'Neutral',
            'explanation': 'No meaningful text found for tone classification.'
        }

    scores = {}
    for label in TONE_MODEL['priors']:
        score = TONE_MODEL['priors'][label]
        for token in tokens:
            score += TONE_MODEL['likelihoods'][label].get(token, TONE_MODEL['likelihoods'][label]['<UNK>'])
        scores[label] = score

    best_label = max(scores, key=scores.get)
    explanation = (
        'Tone classified using a simple Naive Bayes text model trained on formal, informal, and neutral examples.'
    )
    return best_label, {'tone': best_label, 'explanation': explanation}


def analyze_tone(text):
    label, result = predict_tone(text)
    return result


def check_spelling(text):
    words = re.findall(r"\b[a-zA-Z']+\b", text)
    misspelled = {}
    normalized = [re.sub(r"'", '', word).lower() for word in words]
    unknown = spell.unknown(normalized)
    for original, lower in zip(words, normalized):
        if lower in unknown:
            correction = spell.correction(lower) or lower
            if correction != lower:
                misspelled[original] = correction
    return misspelled


def apply_auto_corrections(text, spelling, grammar_errors):
    corrected = text
    for wrong, replacement in spelling.items():
        corrected = re.sub(rf'\b{re.escape(wrong)}\b', replacement, corrected, flags=re.IGNORECASE)

    for pattern, replacement in WRONG_USAGE_PATTERNS:
        corrected = re.sub(pattern, replacement, corrected, flags=re.IGNORECASE)

    for error in grammar_errors:
        target = error.get('target')
        correction = error.get('correction')
        if target and correction:
            corrected = re.sub(re.escape(target), correction, corrected, flags=re.IGNORECASE)

    # Capitalize first character if auto-corrected sentence starts in lowercase
    if corrected and corrected[0].islower():
        corrected = corrected[0].upper() + corrected[1:]
    return corrected


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/check', methods=['POST'])
def check():
    data = request.get_json() or {}
    text = data.get('text', '').strip()
    auto_correct = data.get('auto_correct', False)
    if not text:
        return jsonify({
            'grammar': [],
            'spelling': {},
            'tone': {'tone': 'Neutral', 'explanation': 'No text provided.'},
            'readability': 0.0,
            'word_count': 0,
            'sentence_count': 0,
            'auto_corrected_text': ''
        })

    tool_errors = check_grammar_online(text)
    rule_errors = analyze_grammar(text)
    grammar_errors = merge_grammar_results(tool_errors, rule_errors)
    spelling_errors = check_spelling(text)
    readability = flesch_reading_ease(text)
    tone = analyze_tone(text)
    word_count = compute_word_count(text)
    sentence_count = len([s for s in re.split(r'(?<=[.!?])\s+', text) if s.strip()])
    corrected = apply_auto_corrections(text, spelling_errors, grammar_errors) if auto_correct else ''
    confidence = round(max(0.25, 1.0 - min(len(grammar_errors) + len(spelling_errors), 10) * 0.08), 2)

    return jsonify({
        'grammar': grammar_errors,
        'spelling': spelling_errors,
        'tone': tone,
        'readability': readability,
        'word_count': word_count,
        'sentence_count': sentence_count,
        'auto_corrected_text': corrected,
        'confidence': confidence
    })


if __name__ == '__main__':
    app.run(debug=True)
