document.addEventListener('DOMContentLoaded', () => {
    const inputText = document.getElementById('inputText');
    const checkBtn = document.getElementById('checkBtn');
    const autoCorrect = document.getElementById('autoCorrect');
    const grammarErrors = document.getElementById('grammarErrors');
    const spellingErrors = document.getElementById('spellingErrors');
    const toneLabel = document.getElementById('toneLabel');
    const toneExplanation = document.getElementById('toneExplanation');
    const readability = document.getElementById('readability');
    const wordCount = document.getElementById('wordCount');
    const sentenceCount = document.getElementById('sentenceCount');
    const grammarCount = document.getElementById('grammarCount');
    const spellingCount = document.getElementById('spellingCount');
    const autoCorrectedText = document.getElementById('autoCorrectedText');

    function showNoIssues() {
        grammarErrors.innerHTML = '<div class="feedback-text">No grammar issues found. Great work!</div>';
        spellingErrors.innerHTML = '<div class="feedback-text">No spelling issues found.</div>';
        grammarCount.textContent = '0';
        spellingCount.textContent = '0';
    }

    function renderIssueItem(issue) {
        return `
            <div class="feedback-item">
                <strong>${issue.message}</strong>
                <p><strong>Explanation:</strong> ${issue.explanation}</p>
                <p><strong>Suggestion:</strong> ${issue.suggestions.length ? issue.suggestions.join(', ') : 'Review wording'}</p>
            </div>
        `;
    }

    async function updateStats(data) {
        wordCount.textContent = data.word_count;
        sentenceCount.textContent = data.sentence_count;
        readability.textContent = data.readability;
        toneLabel.textContent = data.tone.tone;
        toneExplanation.textContent = data.tone.explanation;
        grammarCount.textContent = data.grammar.length;
        spellingCount.textContent = Object.keys(data.spelling).length;
        autoCorrectedText.textContent = data.auto_corrected_text || 'Enable auto-correct and run the check to preview corrected text.';
    }

    checkBtn.addEventListener('click', async () => {
        const text = inputText.value.trim();
        if (!text) {
            grammarErrors.innerHTML = '<div class="feedback-text">Please enter some text to analyze.</div>';
            spellingErrors.innerHTML = '<div class="feedback-text">Please enter some text to analyze.</div>';
            return;
        }

        grammarErrors.innerHTML = '<div class="feedback-text">Analyzing grammar...</div>';
        spellingErrors.innerHTML = '<div class="feedback-text">Analyzing spelling...</div>';
        autoCorrectedText.textContent = 'Generating corrected text...';

        try {
            const response = await fetch('/check', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ text, auto_correct: autoCorrect.checked })
            });
            const data = await response.json();

            if (data.grammar.length === 0) {
                grammarErrors.innerHTML = '<div class="feedback-text">No grammar issues found. Your writing is strong.</div>';
            } else {
                grammarErrors.innerHTML = data.grammar.map(renderIssueItem).join('');
            }

            const spellingEntries = Object.entries(data.spelling);
            if (spellingEntries.length === 0) {
                spellingErrors.innerHTML = '<div class="feedback-text">No spelling errors detected.</div>';
            } else {
                spellingErrors.innerHTML = spellingEntries.map(([wrong, correct]) => `
                    <div class="feedback-item">
                        <strong>Misspelled: ${wrong}</strong>
                        <p><strong>Correction:</strong> ${correct}</p>
                    </div>
                `).join('');
            }

            updateStats(data);
        } catch (error) {
            grammarErrors.innerHTML = '<div class="feedback-text">Unable to connect to the server. Is the app running?</div>';
            spellingErrors.innerHTML = '<div class="feedback-text">Unable to connect to the server.</div>';
            autoCorrectedText.textContent = 'Auto-correct preview unavailable.';
            console.error(error);
        }
    });

    showNoIssues();
});
